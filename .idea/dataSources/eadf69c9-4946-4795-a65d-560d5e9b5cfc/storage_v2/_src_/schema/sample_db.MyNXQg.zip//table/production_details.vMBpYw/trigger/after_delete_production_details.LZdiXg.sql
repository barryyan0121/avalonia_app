create definer = root@localhost trigger after_delete_production_details
    after delete
    on production_details
    for each row
BEGIN
    CALL UpdateProductionData();
END;


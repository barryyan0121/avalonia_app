create definer = root@localhost trigger after_update_daily_target
    after update
    on daily_target
    for each row
BEGIN
    CALL UpdateProductionData();
END;


create definer = root@localhost trigger after_update_production_details
    after update
    on production_details
    for each row
BEGIN
    CALL UpdateProductionData();
END;


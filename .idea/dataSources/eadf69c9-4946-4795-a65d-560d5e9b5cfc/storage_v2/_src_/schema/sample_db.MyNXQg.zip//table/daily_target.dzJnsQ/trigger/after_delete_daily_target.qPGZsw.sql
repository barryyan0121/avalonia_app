create definer = root@localhost trigger after_delete_daily_target
    after delete
    on daily_target
    for each row
BEGIN
    CALL UpdateProductionData();
END;


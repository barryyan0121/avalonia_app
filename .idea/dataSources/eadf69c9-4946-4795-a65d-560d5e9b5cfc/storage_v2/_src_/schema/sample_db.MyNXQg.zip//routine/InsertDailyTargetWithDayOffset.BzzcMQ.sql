create
    definer = sample_user@`%` procedure InsertDailyTargetWithDayOffset(IN day_offset int, IN num_days int)
BEGIN
    DECLARE counter INT DEFAULT 0;

    WHILE counter < num_days DO
            INSERT INTO daily_target (name, target_amount, date)
            SELECT name,
                   FLOOR(RAND() * 300) + 1000 AS target_amount, -- Random target amount between 1000 and 1300
                   CURDATE() - INTERVAL (day_offset + counter) DAY AS date
            FROM (SELECT '胶纸切割' AS name
                  UNION ALL
                  SELECT '板框焊接'
                  UNION ALL
                  SELECT '板组件A'
                  UNION ALL
                  SELECT '板组件B'
                  UNION ALL
                  SELECT '框膜组件检测'
                  UNION ALL
                  SELECT '膜框组件A'
                  UNION ALL
                  SELECT '膜框组件B'
                  UNION ALL
                  SELECT '三合一电池A'
                  UNION ALL
                  SELECT '三合一电池B'
                  UNION ALL
                  SELECT '三合一电池C'
                  UNION ALL
                  SELECT '三合一电池检测'
                  UNION ALL
                  SELECT '总装线') AS products;

            SET counter = counter + 1;
        END WHILE;
END;


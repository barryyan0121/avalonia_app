create
    definer = sample_user@`%` procedure InsertProductionDetailsWithCurdate(IN num_repeats int)
BEGIN
    DECLARE counter INT DEFAULT 0;

    WHILE counter < num_repeats
        DO
            -- Insert data into production_details
            INSERT INTO production_details (name, operator_id, machine_id, is_qualified, production_time)
            SELECT name,
                   FLOOR(RAND() * 10) + 1                                                 AS operator_id,    -- Random operator ID
                   FLOOR(RAND() * 20) + 1                                                 AS machine_id,     -- Random machine ID
                   RAND() > 0.2                                                           AS is_qualified,   -- 80% chance of being qualified
                   CURDATE() + INTERVAL FLOOR(RAND() * 24) HOUR                           AS production_time -- Random hour within the current date
            FROM (SELECT '胶纸切割' AS name
                  UNION ALL
                  SELECT '板框焊接'
                  UNION ALL
                  SELECT '板组件A'
                  UNION ALL
                  SELECT '板组件B'
                  UNION ALL
                  SELECT '框膜组件检测'
                  UNION ALL
                  SELECT '膜框组件A'
                  UNION ALL
                  SELECT '膜框组件B'
                  UNION ALL
                  SELECT '三合一电池A'
                  UNION ALL
                  SELECT '三合一电池B'
                  UNION ALL
                  SELECT '三合一电池C'
                  UNION ALL
                  SELECT '三合一电池检测'
                  UNION ALL
                  SELECT '总装线') AS products
                     CROSS JOIN
                 (SELECT 1 AS repeat_offset) AS repeats; -- Ensure to repeat the required number of times

            -- Increment counter
            SET counter = counter + 1;
        END WHILE;
END;


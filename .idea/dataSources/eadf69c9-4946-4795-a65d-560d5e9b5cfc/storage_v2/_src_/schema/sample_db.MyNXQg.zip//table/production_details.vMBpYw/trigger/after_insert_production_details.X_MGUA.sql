create definer = root@localhost trigger after_insert_production_details
    after insert
    on production_details
    for each row
BEGIN
    CALL UpdateProductionData();
END;


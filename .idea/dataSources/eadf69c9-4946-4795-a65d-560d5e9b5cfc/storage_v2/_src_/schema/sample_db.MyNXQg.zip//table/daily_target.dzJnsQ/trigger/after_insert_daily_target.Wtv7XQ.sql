create definer = root@localhost trigger after_insert_daily_target
    after insert
    on daily_target
    for each row
BEGIN
    CALL UpdateProductionData();
END;

